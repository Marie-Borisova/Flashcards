public class Main {
    public static void main(String[] args) {
        Flashcards f = new Flashcards();
        f.chooseACategoryOfWords();

    }

}